//
//  csv_importer.c
//  csv_importer
//
//  Created by Tony Friday on 12/3/13.
//
//

#include <stdio.h>
#include <stdlib.h>

int
main(void)
{
	FILE* csv = fopen("/Users/tony/Documents/Projects/csv_importer/test/test/s1-24eyeslrl-27.11.13.01.57.01.CSV", "r");
	
	// check if file was opened
	if(!csv)
		printf("File could not be opened.\n");
    
    // counter number of lines in file
    int lines = 0;
    char c;
    do
    {
        c = fgetc(csv);
        if (c == '\n')
        {
            ++lines;
        }
    }
	while (c != EOF);
    
    printf("Done counting lines.\n");
    
    //reset cursor
    rewind(csv);
	
	// skip over first line
	do
  		c = fgetc(csv);
	while (c != '\n');
	
	// temp array for fscanf
	double temp[16];
    
    // 1st dimension of final data array. Return this pointer to access the array!
	double** data = (double**)malloc(lines * sizeof(double*));
    
    // counters the number of line loop events. Should be same a lines variable
    int counter = 0;
	
    // iterate by line
	for(int i = 0; i < lines; i++)
	{
        
		// get first 16 columns
		for(int j = 0; j < 16; j++)
		{
			// add double to temp array
			fscanf(csv, "%lf", &temp[j]);
            
			// skip comma
            fgetc(csv);
		}
        // create 2nd dimension of final double array on heap
        double* ptemp =(double *)malloc(14 * sizeof(double));
		
		// copy correct temp to final array
		for(int j = 0; j < 14; j++)
		{
			ptemp[j] = temp[j+2];
		}
        // point 1st dimension of array to temp array
        data[i] = ptemp;
        
        // not really necessay
        ptemp = NULL;
        counter++;
		
		// skip rest of line
		do
        {
  			c = fgetc(csv);
            
            // check if EOF
            if (feof(csv))
                break;
            
        }        while (c != '\n');
        
        printf("Line %d is completed.\n", counter);
	}
    
    printf("No of lines is %d\n", lines);
	
    // print out final 2D array
    for (int i = 0; i <lines; i++)
	{
		for (int j = 0; j < 14; j++)
		{
			printf("%f, ", data[i][j]);
			if(j == 13)
				printf("\n");		}
	}
    
}


